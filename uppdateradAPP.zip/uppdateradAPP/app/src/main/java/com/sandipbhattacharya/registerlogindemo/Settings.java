package com.sandipbhattacharya.registerlogindemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Settings extends AppCompatActivity {
    TextView user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        user=findViewById(R.id.showuserinfo);
        /*Intent intent=getIntent();
        String Email = intent.getStringExtra("email");
        user.setText(Email);
        System.out.println(Email);*/

        Bundle extras = getIntent().getExtras();
        if(extras!=null)
        {
           user.setText(extras.getString("email"));
        }
    }
}